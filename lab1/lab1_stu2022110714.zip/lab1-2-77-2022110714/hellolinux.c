#include<stdio.h>
int main(){
	printf("Hello 2022110714 殷家琦\n");
	return 0;
}
